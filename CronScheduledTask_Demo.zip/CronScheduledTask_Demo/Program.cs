﻿using System; 
using System.IO;
using System.Threading;
using System.Threading.Tasks;

class Program
{
   public static async Task Main(string[] args) 
    {
        // Configuration: set the interval and duration for the task
        int intervalMinutes = 2;
        int taskDurationMinutes = 10;
        string filePath = "CronExample.txt";   // Specify the full file path here

        int n = taskDurationMinutes / intervalMinutes; //n is the no of iterations this task will run.
        Console.WriteLine($"Scheduled Job will run {n} times every {intervalMinutes} minutes.");
        
        for(int i=0;i<n;i++)
        {
            string msg = $"hi there - {DateTime.Now}\n";

            await File.AppendAllTextAsync(filePath, msg);

            //Add a log to the Console to track each iteration
            Console.WriteLine($"Printed {i+1}/{n} to the file {filePath}"); 

            //Wait for the next interval unless it's the final iteration
            if (i< n-1) 
            {
                await Task.Delay(TimeSpan.FromMinutes(intervalMinutes));  //syntax: Task.Delay(int millisecondsDelay);  
            }
        }

        Console.WriteLine("Demo Job completed!");
    }
}

